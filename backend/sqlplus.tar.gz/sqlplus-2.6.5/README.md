Data analysis with no hassle of learning pandas or sql

[DOCS] (https://sqlplus.readthedocs.io/en/latest/)